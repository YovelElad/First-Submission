<!DOCTYPE html>
<html>
<head>

</head>
<body>

</body>
<?php
    echo הפרטים נקלטו בהצלחה!;


    ?>
</html>